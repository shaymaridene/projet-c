#include <gtk/gtk.h>


void
on_buttonajouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);
